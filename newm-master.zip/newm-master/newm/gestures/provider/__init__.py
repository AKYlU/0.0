from .provider import GestureProvider
from .c_gestures import CGestureProvider
from .pyevdev_provider import PyEvdevGestureProvider
