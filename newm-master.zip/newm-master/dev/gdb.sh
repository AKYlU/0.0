#!/bin/sh
gdb -x gdb-script
